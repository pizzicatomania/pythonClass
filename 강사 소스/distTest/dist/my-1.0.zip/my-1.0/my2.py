def my2fn():
    print("my2fn call..")