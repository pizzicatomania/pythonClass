from distutils.core import setup

setup( name="my", version='1.0', py_modules=['my1','my2'] )