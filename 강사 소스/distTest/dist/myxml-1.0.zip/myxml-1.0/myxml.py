def myxmlfn():
    print("myxlmfn")