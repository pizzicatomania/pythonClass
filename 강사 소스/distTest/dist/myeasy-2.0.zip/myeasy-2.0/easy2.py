def easy2Fn():
    print("easy2fn call")