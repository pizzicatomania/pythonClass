from distutils.core import setup

setup(name='lgpack',version='1.0', packages=['lg','lg.com', 'lg.ui'] )

# setup( name="my", version='1.0', py_modules=['my1','my2'] )