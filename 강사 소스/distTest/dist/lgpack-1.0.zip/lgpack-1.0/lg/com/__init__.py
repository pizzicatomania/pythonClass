__all__ =["com11","com22"]
print("com init...")