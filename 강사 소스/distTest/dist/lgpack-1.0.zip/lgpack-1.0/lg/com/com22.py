def com22fn():
    print("com22fn")


print("com22 py ....")