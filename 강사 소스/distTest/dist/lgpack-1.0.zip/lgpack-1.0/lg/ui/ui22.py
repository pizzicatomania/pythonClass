def ui22fn():
    print("ui22fn")


print("ui22 py ....")